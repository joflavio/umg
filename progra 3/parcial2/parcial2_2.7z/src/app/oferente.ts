export class Oferente {
    public nombre:string ="";
    public monto:number = 0.00; 
    constructor (nombre, monto){
      this.monto=monto;
      this.nombre=nombre;
    }
}
