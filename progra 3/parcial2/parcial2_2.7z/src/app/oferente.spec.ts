import { Oferente } from './oferente';

describe('Oferente', () => {
  it('should create an instance', () => {
    expect(new Oferente()).toBeTruthy();
  });
});
